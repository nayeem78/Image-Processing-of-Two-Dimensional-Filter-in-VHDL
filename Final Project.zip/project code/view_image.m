file = dlmread('Lena128x128g_8bits.dat');
file2 = dlmread('Lena128x128g_8bits_r.dat');
strpixels = num2str(file);
decpixels = uint8(bin2dec(strpixels)); %8 bit pixels
image = reshape(decpixels,[128,128])';
strpixels2 = num2str(file2);
decpixels2 = uint8(bin2dec(strpixels2)); %8 bit pixels
image2 = reshape(decpixels2,[128,128])';
subplot(1,2,1);
imshow(image, []);
subplot(1,2,2);
imshow(image2, []);